

/*

$$$$$$\            $$\                                               
$$  __$$\           $$ |                                              
$$ /  \__|$$\   $$\ $$$$$$$\  $$$$$$$$\  $$$$$$\   $$$$$$\   $$$$$$\  
\$$$$$$\  $$ |  $$ |$$  __$$\ \____$$  |$$  __$$\ $$  __$$\ $$  __$$\ 
 \____$$\ $$ |  $$ |$$ |  $$ |  $$$$ _/ $$$$$$$$ |$$ |  \__|$$ /  $$ |
$$\   $$ |$$ |  $$ |$$ |  $$ | $$  _/   $$   ____|$$ |      $$ |  $$ |
\$$$$$$  |\$$$$$$  |$$$$$$$  |$$$$$$$$\ \$$$$$$$\ $$ |      \$$$$$$  |
 \______/  \______/ \_______/ \________| \_______|\__|       \______/

Project Name : SubZero MD
Creator      : Darrell Mucheri ( Mr Frank OFC )
Repo         : https//github.com/mrfrank-ofc/SUBZERO-MD
Support      : wa.me/18062212660
*/




























const _0x8fdd9b=_0x1326;(function(_0x2e4c9f,_0x116f1a){const _0x145e95=_0x1326,_0x550374=_0x2e4c9f();while(!![]){try{const _0x1221ac=-parseInt(_0x145e95(0x11d))/0x1+parseInt(_0x145e95(0x109))/0x2*(-parseInt(_0x145e95(0x122))/0x3)+-parseInt(_0x145e95(0x10e))/0x4+-parseInt(_0x145e95(0x110))/0x5+parseInt(_0x145e95(0xfd))/0x6+-parseInt(_0x145e95(0x116))/0x7+-parseInt(_0x145e95(0x11c))/0x8*(-parseInt(_0x145e95(0x114))/0x9);if(_0x1221ac===_0x116f1a)break;else _0x550374['push'](_0x550374['shift']());}catch(_0x250aee){_0x550374['push'](_0x550374['shift']());}}}(_0x2458,0xdb425));function hi(){const _0x1211a9=_0x1326;console[_0x1211a9(0xf8)]('Hello\x20World!');}hi();function hi(){const _0x5052dc=_0x1326;console[_0x5052dc(0xf8)]('Hello\x20World!');}function _0x1326(_0x94ea3b,_0x1d5290){const _0x2458a4=_0x2458();return _0x1326=function(_0x1326e0,_0x508878){_0x1326e0=_0x1326e0-0xf8;let _0x237954=_0x2458a4[_0x1326e0];return _0x237954;},_0x1326(_0x94ea3b,_0x1d5290);}function _0x2458(){const _0x1693b7=['yt-search','ytvid2','join','3209912tpsxeh','*Please\x20provide\x20a\x20video\x20tital\x20or\x20url*','2531125xykyoR','videos','result','axios','42391341DIZvzb','*Please\x20provide\x20a\x20audio\x20title\x20or\x20url*','4342198GedHxj','ytplay2','../command','video','video/mp4','❌\x20Failed\x20to\x20fetch\x20video\x20for\x20\x22','8hqiBiD','1324261OFaAFC','play2','error','length','sendMessage','107871LtveEP','log','❌\x20An\x20error\x20occurred\x20while\x20processing\x20your\x20request.','ytvideo2','url','ytv2','2472318JkKYwY','>©\x20sᴜʙZᴇʀᴏ\x20ɢᴇɴᴇʀᴀᴛɪɴɢ\x20sᴏɴɢ2\x20ᴘʟᴇᴀsᴇ\x20ᴡᴀɪᴛ...','data','video2','audio/mp4','yta2','get','https://api.giftedtech.web.id/api/download/dlmp4?apikey=gifted&url=','Download\x20audio\x20from\x20YouTube\x20by\x20searching\x20for\x20keywords.','https://api.giftedtech.web.id/api/download/dlmp3?apikey=gifted&url=','music','Download\x20videos\x20from\x20YouTube\x20by\x20searching\x20for\x20keywords.','54Dvpnva','> ©\x20sᴜʙZᴇʀᴏ\x20ɢᴇɴᴇʀᴀᴛɪɴɢ\x20ᴠɪᴅᴇᴏ\x20ᴘʟᴇᴀsᴇ\x20ᴘᴀɪᴛ...'];_0x2458=function(){return _0x1693b7;};return _0x2458();}hi();const {cmd,commands}=require(_0x8fdd9b(0x118)),yts=require(_0x8fdd9b(0x10b)),axios=require(_0x8fdd9b(0x113));cmd({'pattern':_0x8fdd9b(0x100),'alias':[_0x8fdd9b(0x10c),_0x8fdd9b(0xfc),_0x8fdd9b(0xfa)],'react':'⏳','desc':_0x8fdd9b(0x108),'category':_0x8fdd9b(0x119),'use':'.vidx\x20<keywords>','filename':__filename},async(_0xe2f6b0,_0xc0bd08,_0x122f70,{from:_0x4938ec,args:_0x545fb3,reply:_0x290209})=>{const _0x2e6af7=_0x8fdd9b;try{const _0x32deeb=_0x545fb3[_0x2e6af7(0x10d)]('\x20');if(!_0x32deeb)return _0x290209(_0x2e6af7(0x10f));_0x290209(_0x2e6af7(0x10a));const _0x5e6ce9=await yts(_0x32deeb);if(!_0x5e6ce9[_0x2e6af7(0x111)]||_0x5e6ce9[_0x2e6af7(0x111)][_0x2e6af7(0x120)]===0x0)return _0x290209('❌\x20No\x20results\x20found\x20for\x20\x22'+_0x32deeb+'\x22.');const _0x8cec1e=_0x5e6ce9[_0x2e6af7(0x111)][0x0],_0x5ce282=_0x8cec1e['url'],_0x2af2d2=_0x2e6af7(0x104)+_0x5ce282,_0x442320=await axios['get'](_0x2af2d2);if(!_0x442320[_0x2e6af7(0xff)]['success'])return _0x290209(_0x2e6af7(0x11b)+_0x32deeb+'\x22.');const {download_url:_0x503033}=_0x442320[_0x2e6af7(0xff)][_0x2e6af7(0x112)];await _0xe2f6b0[_0x2e6af7(0x121)](_0x4938ec,{'video':{'url':_0x503033},'mimetype':_0x2e6af7(0x11a)},{'quoted':_0xc0bd08});}catch(_0x3da04a){console[_0x2e6af7(0x11f)](_0x3da04a),_0x290209('❌\x20An\x20error\x20occurred\x20while\x20processing\x20your\x20request.');}}),cmd({'pattern':_0x8fdd9b(0x11e),'alias':[_0x8fdd9b(0x102),_0x8fdd9b(0x117)],'react':'⏳','desc':_0x8fdd9b(0x105),'category':_0x8fdd9b(0x107),'use':'.playx\x20<keywords>','filename':__filename},async(_0x1014d1,_0x44f57d,_0x281123,{from:_0x22ebe3,args:_0x445711,reply:_0x377273})=>{const _0x552fd2=_0x8fdd9b;try{const _0x356223=_0x445711['join']('\x20');if(!_0x356223)return _0x377273(_0x552fd2(0x115));_0x377273(_0x552fd2(0xfe));const _0x271698=await yts(_0x356223);if(!_0x271698[_0x552fd2(0x111)]||_0x271698[_0x552fd2(0x111)][_0x552fd2(0x120)]===0x0)return _0x377273('❌\x20No\x20results\x20found\x20for\x20\x22'+_0x356223+'\x22.');const _0x4360a6=_0x271698[_0x552fd2(0x111)][0x0],_0x57ffbc=_0x4360a6[_0x552fd2(0xfb)],_0x3af9d4=_0x552fd2(0x106)+_0x57ffbc,_0x1d283c=await axios[_0x552fd2(0x103)](_0x3af9d4);if(!_0x1d283c[_0x552fd2(0xff)]['success'])return _0x377273('❌\x20Failed\x20to\x20fetch\x20audio\x20for\x20\x22'+_0x356223+'\x22.');const {download_url:_0x3a6e3b}=_0x1d283c[_0x552fd2(0xff)][_0x552fd2(0x112)];await _0x1014d1[_0x552fd2(0x121)](_0x22ebe3,{'audio':{'url':_0x3a6e3b},'mimetype':_0x552fd2(0x101),'ptt':![]},{'quoted':_0x44f57d});}catch(_0x274411){console[_0x552fd2(0x11f)](_0x274411),_0x377273(_0x552fd2(0xf9));}});
